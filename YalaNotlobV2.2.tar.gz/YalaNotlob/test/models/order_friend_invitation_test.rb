require 'test_helper'

class OrderFriendInvitationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
