class OrderFriendInvitationsController < ApplicationController
	skip_before_filter :verify_authenticity_token  
	before_action :set_order_friend_invitation, only: [:show, :edit, :update, :destroy]

	def index
		@user = User.find(params[:user_id])
		@order = @user.orders.find(params[:order_id])
		@invited_friends = @order.order_friend_invitations
		@invited_friends_ids = []
		@invited_friends.each do |inv| 
			@invited_friends_ids << inv.user_id.to_i
		end
		@invited_friends = User.where(id: @invited_friends_ids)
	end

	def joined
		@user = User.find(params[:user_id])
		@order = @user.orders.find(params[:order_id])
		@joined_friends = @order.order_friend_invitations.where("pending=?", false)
		@joined_friends_ids = []
		@joined_friends.each do |inv| 
			@joined_friends_ids << inv.user_id.to_i
		end
		@joined_friends = User.where(id: @joined_friends_ids)
		#render plain: @joined_friends.inspect
	end

	def new
		#@user = User.find(params[:user_id])
		@order = current_user.orders.find(params[:order_id])
		@order_friend_invitation = @order.order_friend_invitations.new
	end


	def create
		@invited_friends = params[:invited_friends]
		#render plain: @invited_friends.inspect
		@invited_friends.each do |invited_friend_id|
				@order_friend_invitation = current_user.orders.find(params[:order_id]).order_friend_invitations.build(:user_id => invited_friend_id)
	  		@order_friend_invitation.save
	  end
	  redirect_to user_order_order_friend_invitations_path
	  # if @order_friend_invitation.save
	  #   flash[:notice] = "Invited friend."
	  #   redirect_to root_url
	  # else
	  #   flash[:notice] = "Unable to invite friend."
	  #   redirect_to root_url
	  # end
	end

	def destroy

	end
end
