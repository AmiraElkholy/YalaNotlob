# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)

user = User.create([{ name: 'Amira', email: "1@g.com", password: "123123" },
	{ name: 'Amira', email: "2@g.com", password: "123123" },
	{ name: 'Amira', email: "3@g.com", password: "123123" },
	{ name: 'Amira', email: "4@g.com", password: "123123" },
	{ name: 'Amira', email: "5@g.com", password: "123123" },
	{ name: 'Amira', email: "6@g.com", password: "123123" },
	{ name: 'Amira', email: "7@g.com", password: "123123" },
	{ name: 'Amira', email: "8@g.com", password: "123123" },
	{ name: 'Amira', email: "9@g.com", password: "123123" },
	{ name: 'Amira', email: "10@g.com", password: "123123" },
	{ name: 'Amira', email: "11@g.com", password: "123123" },
	{ name: 'Amira', email: "12@g.com", password: "123123" },
	{ name: 'Amira', email: "13@g.com", password: "123123" },
	{ name: 'Amira', email: "14@g.com", password: "123123" },
	{ name: 'Amira', email: "15@g.com", password: "123123" },
	{ name: 'Amira', email: "16@g.com", password: "123123" },
	{ name: 'Amira', email: "17@g.com", password: "123123" },
	{ name: 'Amira', email: "18@g.com", password: "123123" },
	{ name: 'Amira', email: "19@g.com", password: "123123" },
	{ name: 'Amira', email: "20@g.com", password: "123123" },
	{ name: 'Amira', email: "21@g.com", password: "123123" },
	{ name: 'Amira', email: "22@g.com", password: "123123" },
	{ name: 'Amira', email: "23@g.com", password: "123123" },
	{ name: 'Amira', email: "34@g.com", password: "123123" },
	{ name: 'Amira', email: "433@g.com", password: "123123" },
	{ name: 'Amira', email: "986@g.com", password: "123123" },
	{ name: 'Amira', email: "987@g.com", password: "123123" },
	{ name: 'Amira', email: "999@g.com", password: "123123" },
	{ name: 'Amira', email: "1000@g.com", password: "123123" }])
