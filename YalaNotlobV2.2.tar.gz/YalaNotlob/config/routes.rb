Rails.application.routes.draw do
  devise_for :users
  root 'welcome#index'
  resources :friendships
  resources :users do
  	collection do
  	  get :autocomplete
  	end
    resources :orders do
      patch :finish
      resources :items
      resources :order_friend_invitations do
        collection do
          get :joined
        end
      end
    end
    resources :friends 
  end
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
